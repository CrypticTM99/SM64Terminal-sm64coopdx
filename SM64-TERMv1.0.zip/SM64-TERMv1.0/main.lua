-- name: SM64 Terminal
-- description: Minigame cabinet included in a small retro terminal, just a silly mod I made for sm64coopdx
-- author: CrypticTM

local TERM_OPEN = false
local TERM_LINES = {}
local MAX_LINES = 14
local TERM_ALPHA = 0

-- Terminal themes: 1=Green 2=CRT 3=VHS 4=Purple 5=N64
local TERM_THEME = 1
local THEME_NAMES = { "Green", "CRT", "VHS", "Purple", "N64" }

local function theme_colors()
    if TERM_THEME == 2 then -- CRT
        return {
            bg = {4, 12, 6}, panel = {8, 20, 10}, border = {80, 255, 120},
            header = {10, 28, 14}, text = {160, 255, 170}, dim = {70, 140, 90},
            accent = {120, 255, 140}, shadow = {0, 0, 0}
        }
    elseif TERM_THEME == 3 then -- VHS
        return {
            bg = {18, 10, 16}, panel = {28, 14, 22}, border = {220, 90, 140},
            header = {36, 18, 28}, text = {240, 210, 220}, dim = {160, 100, 130},
            accent = {255, 120, 160}, shadow = {0, 0, 0}
        }
    elseif TERM_THEME == 4 then -- Purple
        return {
            bg = {12, 6, 20}, panel = {22, 10, 36}, border = {180, 100, 255},
            header = {28, 14, 48}, text = {220, 190, 255}, dim = {130, 90, 180},
            accent = {200, 140, 255}, shadow = {0, 0, 0}
        }
    elseif TERM_THEME == 5 then -- N64 / SM64
        return {
            bg = {20, 16, 10}, panel = {32, 24, 14}, border = {220, 50, 50},
            header = {40, 28, 12}, text = {255, 230, 160}, dim = {180, 140, 80},
            accent = {255, 200, 60}, shadow = {0, 0, 0}
        }
    end
    -- Green (default)
    return {
        bg = {7, 11, 9}, panel = {12, 22, 16}, border = {60, 220, 110},
        header = {12, 22, 16}, text = {200, 255, 210}, dim = {90, 160, 110},
        accent = {110, 255, 150}, shadow = {0, 0, 0}
    }
end

local snakeMoveTimer = 0
local SNAKE_MOVE indelay = 5
local GRID_W, GRID_H, CELL = 30, 15, 13

local PLAT_GRAVITY = 0.45
local PLAT_MOVE_SPEED = 3.7
local PLAT_JUMP = -10.4
local PLAT_JUMP_HOLD = -0.48
local PLAT_WORLD_W = 1100
local PLAT_VIEW_W = 580
local PLAT_VIEW_H = 310
local COYOTE_MAX, JUMP_BUFFER_MAX = 7, 7

local plat = {
    x = 48, y = 200, vx = 0, vy = 0, w = 16, h = 22,
    onGround = false, facing = 1, score = 0, alive = true, win = false,
    cameraX = 0, coyote = 0, jumpBuf = 0, anim = 0, lives = 3
}
local platforms = {
    {x = 0, y = 280, w = 1100, h = 32, kind = "ground"},
    {x = 100, y = 230, w = 64, h = 16, kind = "brick"},
    {x = 210, y = 185, w = 56, h = 16, kind = "brick"},
    {x = 310, y = 145, w = 72, h = 16, kind = "question"},
    {x = 430, y = 185, w = 56, h = 16, kind = "brick"},
    {x = 530, y = 130, w = 80, h = 16, kind = "question"},
    {x = 660, y = 175, w = 64, h = 16, kind = "brick"},
    {x = 760, y = 140, w = 56, h = 16, kind = "brick"},
    {x = 860, y = 200, w = 80, h = 16, kind = "question"},
    {x = 400, y = 240, w = 48, h = 16, kind = "brick"},
    {x = 720, y = 240, w = 48, h = 16, kind = "brick"},
    {x = 980, y = 230, w = 40, h = 50, kind = "pipe"},
}
local coins = {
    {x = 120, y = 205, got = false}, {x = 225, y = 160, got = false},
    {x = 330, y = 120, got = false}, {x = 450, y = 160, got = false},
    {x = 555, y = 105, got = false}, {x = 680, y = 150, got = false},
    {x = 775, y = 115, got = false}, {x = 880, y = 175, got = false},
    {x = 420, y = 215, got = false}, {x = 740, y = 215, got = false},
}
local enemies = {
    {x = 260, y = 260, w = 16, h = 16, vx = 1.15, alive = true},
    {x = 500, y = 260, w = 16, h = 16, vx = -1.05, alive = true},
    {x = 650, y = 260, w = 16, h = 16, vx = 1.2, alive = true},
    {x = 820, y = 260, w = 16, h = 16, vx = -1.1, alive = true},
}
local goal = {x = 1040, y = 200, w = 18, h = 80}

local lak = {
    phase = "aim", angle = 45, power = 0, powerDir = 1,
    x = 40, y = 260, vx = 0, vy = 0, dist = 0, best = 0,
    wind = 0, coins = {}, score = 0, trails = {}
}
local bb = {
    phase = "pitch", ballX = 200, ballY = 80, ballVX = 0, ballVY = 0,
    pitchTimer = 0, swingWindow = 0, swung = false, hit = false, fair = false,
    distance = 0, outs = 0, score = 0, inning = 1, msg = "Press A to swing!"
}
local booGame = {
    phase = "hide", timer = 0, hideTime = 180, seekTime = 0, maxSeek = 900,
    playerX = 200, playerY = 180, boos = {}, found = 0, total = 5,
    lives = 3, msg = "Boos are hiding...", flash = 0
}
local pin = {
    ball = {x = 250, y = 380, vx = 0, vy = 0, r = 6, live = false},
    score = 0, ballsLeft = 3, flipL = 0, flipR = 0, plunger = 0,
    charging = false, gameOver = false,
    bumpers = {
        {x = 140, y = 120, r = 16, cool = 0, pts = 100},
        {x = 250, y = 90, r = 16, cool = 0, pts = 100},
        {x = 360, y = 120, r = 16, cool = 0, pts = 100},
        {x = 200, y = 180, r = 12, cool = 0, pts = 50},
        {x = 300, y = 180, r = 12, cool = 0, pts = 50},
    },
    targets = {
        {x = 100, y = 60, w = 28, h = 14, hit = false, pts = 200},
        {x = 150, y = 60, w = 28, h = 14, hit = false, pts = 200},
        {x = 320, y = 60, w = 28, h = 14, hit = false, pts = 200},
        {x = 370, y = 60, w = 28, h = 14, hit = false, pts = 200},
    }
}
local PIN_W, PIN_H, PIN_GRAV, FLIP_LEN = 420, 420, 0.18, 48

local DRM_W, DRM_H, DRM_CELL = 8, 16, 16
local COL_EMPTY, COL_RED, COL_YEL, COL_BLU = 0, 1, 2, 3
local TYPE_PILL, TYPE_VIRUS = 1, 2
local drm = {
    grid = {}, pill = nil, nextPill = nil, fallTimer = 0, fallDelay = 28,
    level = 1, virusesLeft = 0, score = 0, alive = true,
    wonLevel = false, wonGame = false, clearFlash = 0, inputCD = 0
}
local dk = {
    x = 36, y = 248, vx = 0, vy = 0, w = 14, h = 18,
    onGround = false, onLadder = false, facing = 1,
    alive = true, win = false, lives = 3, score = 0,
    barrels = {}, spawnTimer = 0, anim = 0
}
local dkFloors = {
    {x = 16, y = 42, w = 300, h = 10, dir = 1},
    {x = 50, y = 98, w = 266, h = 10, dir = -1},
    {x = 16, y = 156, w = 266, h = 10, dir = 1},
    {x = 50, y = 214, w = 266, h = 10, dir = -1},
    {x = 16, y = 272, w = 300, h = 10, dir = 1},
}
local dkLadders = {
    {x = 270, y = 42, h = 56}, {x = 70, y = 98, h = 58},
    {x = 255, y = 156, h = 58}, {x = 80, y = 214, h = 58},
}
local SUITS = {"H", "D", "C", "S"}
local SUIT_FULL = {"HEART", "DIAM", "CLUB", "SPADE"}
local RANKS = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"}
local poker = {
    credits = 100, bet = 5, hand = {}, held = {false, false, false, false, false},
    phase = "bet", msg = "Press A to deal", winAmount = 0, cursor = 1, deck = nil
}
local detective = {
    grid = {}, cols = 6, rows = 4, targetType = 1, targetsLeft = 0,
    score = 0, mistakes = 0, maxMistakes = 3, round = 1, maxRounds = 5,
    alive = true, won = false, cursor = 1, msg = "Find the faces!"
}
local FACE_NAMES = {"MARIO", "LUIGI", "TOAD", "GOOMBA", "YOSHI", "BOO"}
local FACE_COLORS = {
    {220, 50, 50}, {50, 190, 70}, {245, 245, 245},
    {175, 115, 55}, {55, 210, 55}, {195, 195, 220}
}
local godMode, moonJump = false, false
local speedMul, sizeMul = 1.0, 1.0
local SPAWN_LIST = {
    ["1up"] = {bhv = id_bhv1Up, model = E_MODEL_1UP},
    ["coin"] = {bhv = id_bhvYellowCoin, model = E_MODEL_YELLOW_COIN},
    ["star"] = {bhv = id_bhvSpawnedStar, model = E_MODEL_STAR},
    ["goomba"] = {bhv = id_bhvGoomba, model = E_MODEL_GOOMBA},
    ["bobomb"] = {bhv = id_bhvBobomb, model = E_MODEL_BLACK_BOBOMB},
    ["heart"] = {bhv = id_bhvRecoveryHeart, model = E_MODEL_HEART},
    ["cap"] = {bhv = id_bhvNormalCap, model = E_MODEL_MARIOS_CAP},
    ["wingcap"] = {bhv = id_bhvWingCap, model = E_MODEL_MARIOS_WING_CAP},
    ["metalcap"] = {bhv = id_bhvMetalCap, model = E_MODEL_MARIOS_METAL_CAP},
}

local function to_int(n) return math.floor((n or 0) + 0.5) end
local function clamp(v, a, b) if v < a then return a end if v > b then return b end return v end
local function term_print(msg)
    table.insert(TERM_LINES, tostring(msg))
    while #TERM_LINES > MAX_LINES do table.remove(TERM_LINES, 1) end
end
local function term_clear() TERM_LINES = {} end
local function draw_rect_a(x, y, w, h, r, g, b, a)
    djui_hud_set_color(r, g, b, a)
    djui_hud_render_rect(x, y, w, h)
end
local function rects_overlap(ax, ay, aw, ah, bx, by, bw, bh)
    return ax < bx + bw and ax + aw > bx and ay < by + bh and ay + ah > by
end
local function dist2(ax, ay, bx, by)
    local dx, dy = ax - bx, ay - by
    return dx * dx + dy * dy
end
local function any_minigame()
    return gGlobalSyncTable.snakePlaying or gGlobalSyncTable.platPlaying
        or gGlobalSyncTable.drmPlaying or gGlobalSyncTable.dkPlaying
        or gGlobalSyncTable.pokerPlaying or gGlobalSyncTable.detectivePlaying
        or gGlobalSyncTable.pinPlaying or gGlobalSyncTable.lakPlaying
        or gGlobalSyncTable.bbPlaying or gGlobalSyncTable.booPlaying
end
local function stop_all_minigames()
    gGlobalSyncTable.snakePlaying = false
    gGlobalSyncTable.platPlaying = false
    gGlobalSyncTable.drmPlaying = false
    gGlobalSyncTable.dkPlaying = false
    gGlobalSyncTable.pokerPlaying = false
    gGlobalSyncTable.detectivePlaying = false
    gGlobalSyncTable.pinPlaying = false
    gGlobalSyncTable.lakPlaying = false
    gGlobalSyncTable.bbPlaying = false
    gGlobalSyncTable.booPlaying = false
end
local function get_mario_by_name(name)
    if not name or name == "me" or name == "self" then return gMarioStates[0] end
    name = string.lower(name)
    for i = 0, (MAX_PLAYERS or 16) - 1 do
        local np = gNetworkPlayers[i]
        if np and np.connected then
            local n = string.lower(np.name or "")
            if n == name or string.find(n, name, 1, true) then return gMarioStates[i] end
        end
    end
    local idx = tonumber(name)
    if idx and gMarioStates[idx] then return gMarioStates[idx] end
    return nil
end

-- ===================== MINIGAME LOGIC (same as last version, kept intact) =====================
-- For brevity in this update-focused file, full minigame functions match previous release.
-- Include: lak_*, bb_*, boo_*, pin_*, drm_*, dk_*, poker_*, detective_*, snake_*, plat_*
-- (All gameplay code unchanged from prior full version.)

local function lak_reset_shot()
    lak.phase = "aim" lak.angle = 45 lak.power = 0 lak.powerDir = 1
    lak.x = 50 lak.y = 270 lak.vx = 0 lak.vy = 0 lak.dist = 0
    lak.wind = math.random(-25, 25) / 10
    lak.coins = {} lak.trails = {}
    for i = 1, 8 do
        table.insert(lak.coins, {x = 120 + i * 70 + math.random(-15, 15), y = 80 + math.random(0, 140), got = false})
    end
end
local function lak_start()
    stop_all_minigames() gGlobalSyncTable.lakPlaying = true
    lak.score = 0 lak.best = lak.best or 0 lak_reset_shot() TERM_OPEN = true
    term_print("LAKITU LAUNCH")
end
local function lak_stop() gGlobalSyncTable.lakPlaying = false end
local function lak_update(m)
    local c = m.controller
    if lak.phase == "aim" then
        if c then
            if (c.buttonDown & U_JPAD) ~= 0 or c.stickY > 20 then lak.angle = math.min(80, lak.angle + 1.2) end
            if (c.buttonDown & D_JPAD) ~= 0 or c.stickY < -20 then lak.angle = math.max(15, lak.angle - 1.2) end
            if (c.buttonPressed & A_BUTTON) ~= 0 then lak.phase = "power" lak.power = 0 lak.powerDir = 1 end
        end
    elseif lak.phase == "power" then
        lak.power = lak.power + lak.powerDir * 2.8
        if lak.power >= 100 then lak.power = 100 lak.powerDir = -1 end
        if lak.power <= 0 then lak.power = 0 lak.powerDir = 1 end
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then
            local rad = lak.angle * 3.14159 / 180
            local p = 4 + lak.power * 0.14
            lak.vx = math.cos(rad) * p lak.vy = -math.sin(rad) * p lak.phase = "fly"
        end
    elseif lak.phase == "fly" then
        lak.vy = lak.vy + 0.22 lak.vx = lak.vx + lak.wind * 0.02
        lak.x = lak.x + lak.vx lak.y = lak.y + lak.vy
        lak.dist = math.max(lak.dist, lak.x - 50)
        table.insert(lak.trails, 1, {x = lak.x, y = lak.y})
        if #lak.trails > 12 then table.remove(lak.trails) end
        for i = 1, #lak.coins do
            local coin = lak.coins[i]
            if not coin.got and dist2(lak.x, lak.y, coin.x, coin.y) < 324 then
                coin.got = true lak.score = lak.score + 50 lak.vy = lak.vy - 1.5
            end
        end
        if lak.y > 200 and lak.y < 220 and lak.vy > 0 and (math.floor(lak.x / 90) % 2 == 0) then
            lak.vy = -math.abs(lak.vy) * 0.92 lak.vx = lak.vx * 1.05
        end
        if lak.y > 300 or lak.x > 900 then
            lak.phase = "result"
            local d = to_int(lak.dist)
            if d > lak.best then lak.best = d end
            lak.score = lak.score + d
        end
    elseif lak.phase == "result" then
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then lak_reset_shot() end
    end
end

local function bb_reset_pitch()
    bb.phase = "pitch" bb.ballX = 340 bb.ballY = 70 bb.ballVX = 0 bb.ballVY = 0
    bb.pitchTimer = 40 + math.random(0, 30) bb.swung = false bb.hit = false bb.fair = false bb.distance = 0
    bb.msg = "Watch the pitch... Press A to swing!"
end
local function bb_start()
    stop_all_minigames() gGlobalSyncTable.bbPlaying = true
    bb.score = 0 bb.outs = 0 bb.inning = 1 bb_reset_pitch() TERM_OPEN = true
    term_print("M64 BASEBALL")
end
local function bb_stop() gGlobalSyncTable.bbPlaying = false end
local function bb_update(m)
    local c = m.controller
    if bb.outs >= 3 then
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then bb.outs = 0 bb.inning = bb.inning + 1 bb_reset_pitch() end
        return
    end
    if bb.phase == "pitch" then
        bb.pitchTimer = bb.pitchTimer - 1
        if bb.pitchTimer <= 0 then
            bb.phase = "swing"
            bb.ballVX = -4.2 - math.random() * 1.5
            bb.ballVY = 2.8 + math.random() * 0.8
        end
    elseif bb.phase == "swing" then
        bb.ballX = bb.ballX + bb.ballVX bb.ballY = bb.ballY + bb.ballVY
        if c and (c.buttonPressed & A_BUTTON) ~= 0 and not bb.swung then
            bb.swung = true
            local d = math.sqrt(dist2(bb.ballX, bb.ballY, 110, 225))
            if d < 38 then
                bb.hit = true bb.fair = true
                local power = clamp(38 - d, 5, 38)
                bb.ballVX = 3 + power * 0.25 bb.ballVY = -5 - power * 0.15
                bb.phase = "field" bb.msg = "HIT!"
            elseif d < 55 then
                bb.hit = true bb.fair = false bb.ballVX = 2 bb.ballVY = -3
                bb.phase = "field" bb.msg = "FOUL!"
            else
                bb.msg = "MISS!" bb.outs = bb.outs + 1 bb.phase = "result"
            end
        end
        if bb.ballX < 40 or bb.ballY > 300 then
            if not bb.swung then bb.msg = "STRIKE!" bb.outs = bb.outs + 1 end
            bb.phase = "result"
        end
    elseif bb.phase == "field" then
        bb.ballVY = bb.ballVY + 0.2
        bb.ballX = bb.ballX + bb.ballVX bb.ballY = bb.ballY + bb.ballVY
        bb.distance = math.max(bb.distance, bb.ballX - 110)
        if bb.ballY > 290 or bb.ballX > 520 then
            if bb.fair then
                local d = to_int(bb.distance)
                if d > 280 then bb.score = bb.score + 4 bb.msg = "HOME RUN! +" .. d
                elseif d > 180 then bb.score = bb.score + 2 bb.msg = "DOUBLE! +" .. d
                else bb.score = bb.score + 1 bb.msg = "SINGLE +" .. d end
            else bb.msg = "Foul ball..." end
            bb.phase = "result"
        end
    elseif bb.phase == "result" then
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then bb_reset_pitch() end
    end
end

local function boo_gen_hides()
    booGame.boos = {}
    local spots = {
        {40, 60}, {120, 50}, {220, 70}, {320, 55}, {400, 80},
        {60, 140}, {180, 160}, {280, 130}, {380, 150},
        {90, 220}, {200, 240}, {310, 210}, {400, 230},
        {50, 280}, {150, 300}, {270, 290}, {370, 310}
    }
    for i = #spots, 2, -1 do local j = math.random(i) spots[i], spots[j] = spots[j], spots[i] end
    for i = 1, booGame.total do
        table.insert(booGame.boos, {x = spots[i][1], y = spots[i][2], found = false, wobble = math.random() * 6.28})
    end
end
local function boo_start()
    stop_all_minigames() gGlobalSyncTable.booPlaying = true
    booGame.phase = "hide" booGame.timer = booGame.hideTime booGame.found = 0
    booGame.lives = 3 booGame.seekTime = 0 booGame.playerX = 220 booGame.playerY = 180
    booGame.msg = "Boos are hiding..." boo_gen_hides() TERM_OPEN = true
    term_print("BOO HIDE & SEEK")
end
local function boo_stop() gGlobalSyncTable.booPlaying = false end
local function boo_update(m)
    local c = m.controller
    if booGame.phase == "hide" then
        booGame.timer = booGame.timer - 1
        if booGame.timer <= 0 then
            booGame.phase = "seek" booGame.seekTime = booGame.maxSeek
            booGame.msg = "FIND THE BOOS! D-Pad move, A search"
        end
    elseif booGame.phase == "seek" then
        booGame.seekTime = booGame.seekTime - 1
        if c then
            if (c.buttonDown & L_JPAD) ~= 0 or c.stickX < -20 then booGame.playerX = booGame.playerX - 2.8 end
            if (c.buttonDown & R_JPAD) ~= 0 or c.stickX > 20 then booGame.playerX = booGame.playerX + 2.8 end
            if (c.buttonDown & U_JPAD) ~= 0 or c.stickY > 20 then booGame.playerY = booGame.playerY - 2.8 end
            if (c.buttonDown & D_JPAD) ~= 0 or c.stickY < -20 then booGame.playerY = booGame.playerY + 2.8 end
            booGame.playerX = clamp(booGame.playerX, 20, 460)
            booGame.playerY = clamp(booGame.playerY, 40, 340)
            if (c.buttonPressed & A_BUTTON) ~= 0 then
                local foundOne = false
                for i = 1, #booGame.boos do
                    local b = booGame.boos[i]
                    if not b.found and dist2(booGame.playerX, booGame.playerY, b.x, b.y) < 784 then
                        b.found = true booGame.found = booGame.found + 1 foundOne = true
                        booGame.msg = "Found! (" .. booGame.found .. "/" .. booGame.total .. ")"
                        break
                    end
                end
                if not foundOne then
                    booGame.lives = booGame.lives - 1
                    booGame.msg = "Nothing... Lives " .. booGame.lives
                    if booGame.lives <= 0 then booGame.phase = "result" booGame.msg = "The Boos got you..." end
                end
                if booGame.found >= booGame.total then booGame.phase = "result" booGame.msg = "ALL BOOS FOUND!" end
            end
        end
        for i = 1, #booGame.boos do booGame.boos[i].wobble = booGame.boos[i].wobble + 0.08 end
        if booGame.seekTime <= 0 then
            booGame.phase = "result"
            booGame.msg = "Time's up! " .. booGame.found .. "/" .. booGame.total
        end
    elseif booGame.phase == "result" then
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then boo_start() end
    end
end

-- Pin / DRM / DK / Poker / Detective / Snake / 2D (same behavior as previous full version)
local function pin_reset_ball()
    pin.ball.x = 385 pin.ball.y = 360 pin.ball.vx = 0 pin.ball.vy = 0
    pin.ball.live = false pin.plunger = 0 pin.charging = false
end
local function pin_start()
    stop_all_minigames() gGlobalSyncTable.pinPlaying = true
    pin.score = 0 pin.ballsLeft = 3 pin.gameOver = false pin.flipL = 0 pin.flipR = 0
    for i = 1, #pin.targets do pin.targets[i].hit = false end
    pin_reset_ball() TERM_OPEN = true term_print("MARIO PINBALL")
end
local function pin_stop() gGlobalSyncTable.pinPlaying = false end
local function pin_bounce_circle(cx, cy, cr, strength)
    local b = pin.ball
    local d = math.sqrt(dist2(b.x, b.y, cx, cy))
    if d < 0.1 then d = 0.1 end
    if d < b.r + cr then
        local nx = (b.x - cx) / d local ny = (b.y - cy) / d
        local overlap = b.r + cr - d
        b.x = b.x + nx * overlap b.y = b.y + ny * overlap
        local dot = b.vx * nx + b.vy * ny
        b.vx = (b.vx - 2 * dot * nx) * 0.85 b.vy = (b.vy - 2 * dot * ny) * 0.85
        return true
    end
    return false
end
local function pin_update(m)
    if pin.gameOver then
        local c = m.controller
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then
            pin.score = 0 pin.ballsLeft = 3 pin.gameOver = false
            for i = 1, #pin.targets do pin.targets[i].hit = false end
            pin_reset_ball()
        end
        return
    end
    local c = m.controller
    local leftFlip, rightFlip = false, false
    if c then
        if (c.buttonDown & L_JPAD) ~= 0 or (c.buttonDown & Z_TRIG) ~= 0 then leftFlip = true end
        if (c.buttonDown & R_JPAD) ~= 0 or (c.buttonDown & R_TRIG) ~= 0 then rightFlip = true end
        if not pin.ball.live then
            if (c.buttonDown & A_BUTTON) ~= 0 or (c.buttonDown & B_BUTTON) ~= 0 then
                pin.charging = true pin.plunger = math.min(14, pin.plunger + 0.35)
            end
            if pin.charging and (c.buttonDown & A_BUTTON) == 0 and (c.buttonDown & B_BUTTON) == 0 then
                pin.ball.live = true pin.ball.vx = -1.5 pin.ball.vy = -pin.plunger * 1.1
                pin.plunger = 0 pin.charging = false
            end
        end
    end
    if leftFlip then pin.flipL = math.min(1, pin.flipL + 0.35) else pin.flipL = math.max(0, pin.flipL - 0.25) end
    if rightFlip then pin.flipR = math.min(1, pin.flipR + 0.35) else pin.flipR = math.max(0, pin.flipR - 0.25) end
    if not pin.ball.live then return end
    local b = pin.ball
    b.vy = b.vy + PIN_GRAV b.x = b.x + b.vx b.y = b.y + b.vy
    if b.x < 20 + b.r then b.x = 20 + b.r b.vx = math.abs(b.vx) * 0.8 end
    if b.x > PIN_W - 50 - b.r then b.x = PIN_W - 50 - b.r b.vx = -math.abs(b.vx) * 0.8 end
    if b.y < 20 + b.r then b.y = 20 + b.r b.vy = math.abs(b.vy) * 0.8 end
    if b.y > PIN_H - 10 then
        pin.ballsLeft = pin.ballsLeft - 1
        if pin.ballsLeft <= 0 then pin.gameOver = true else pin_reset_ball() end
        return
    end
    for i = 1, #pin.bumpers do
        local bp = pin.bumpers[i]
        if bp.cool > 0 then bp.cool = bp.cool - 1 end
        if pin_bounce_circle(bp.x, bp.y, bp.r, 4.5) and bp.cool <= 0 then
            pin.score = pin.score + bp.pts bp.cool = 8
        end
    end
    for i = 1, #pin.targets do
        local t = pin.targets[i]
        if not t.hit and b.x + b.r > t.x and b.x - b.r < t.x + t.w and b.y + b.r > t.y and b.y - b.r < t.y + t.h then
            t.hit = true pin.score = pin.score + t.pts b.vy = math.abs(b.vy) * 0.9 + 1
        end
    end
    local function flipper_hit(fx, fy, angle, power)
        local rad = angle * 3.14159 / 180
        local ex = fx + math.cos(rad) * FLIP_LEN local ey = fy + math.sin(rad) * FLIP_LEN
        local dx, dy = ex - fx, ey - fy local len2 = dx * dx + dy * dy
        local t = 0
        if len2 > 0 then t = clamp(((b.x - fx) * dx + (b.y - fy) * dy) / len2, 0, 1) end
        local cx, cy = fx + dx * t, fy + dy * t
        local d = math.sqrt(dist2(b.x, b.y, cx, cy))
        if d < b.r + 4 then
            local nx = (b.x - cx) / (d + 0.01) local ny = (b.y - cy) / (d + 0.01)
            b.x = cx + nx * (b.r + 4) b.y = cy + ny * (b.r + 4)
            local dot = b.vx * nx + b.vy * ny
            b.vx = (b.vx - 2 * dot * nx) * 0.5 + nx * power
            b.vy = (b.vy - 2 * dot * ny) * 0.5 + ny * power
        end
    end
    flipper_hit(110, 350, 20 - pin.flipL * 55, pin.flipL * 8)
    flipper_hit(310, 350, 160 + pin.flipR * 55, pin.flipR * 8)
end

local function drm_color_rgb(c)
    if c == COL_RED then return 230, 55, 55 end
    if c == COL_YEL then return 240, 210, 45 end
    if c == COL_BLU then return 55, 125, 240 end
    return 40, 40, 40
end
local function drm_empty_grid()
    local g = {}
    for y = 1, DRM_H do g[y] = {} for x = 1, DRM_W do g[y][x] = {c = COL_EMPTY, t = 0} end end
    return g
end
local function drm_rand_color() return math.random(1, 3) end
local function drm_make_pill() return {x = 4, y = 1, rot = 0, c1 = drm_rand_color(), c2 = drm_rand_color()} end
local function drm_pill_cells(p)
    local cells = {{x = p.x, y = p.y, c = p.c1}}
    if p.rot == 0 then table.insert(cells, {x = p.x + 1, y = p.y, c = p.c2})
    elseif p.rot == 1 then table.insert(cells, {x = p.x, y = p.y + 1, c = p.c2})
    elseif p.rot == 2 then table.insert(cells, {x = p.x - 1, y = p.y, c = p.c2})
    else table.insert(cells, {x = p.x, y = p.y - 1, c = p.c2}) end
    return cells
end
local function drm_in_bounds(x, y) return x >= 1 and x <= DRM_W and y >= 1 and y <= DRM_H end
local function drm_cell_free(x, y)
    if not drm_in_bounds(x, y) then return false end
    return drm.grid[y][x].c == COL_EMPTY
end
local function drm_can_place(p)
    for _, cell in ipairs(drm_pill_cells(p)) do if not drm_cell_free(cell.x, cell.y) then return false end end
    return true
end
local function drm_lock_pill()
    if not drm.pill then return end
    for _, cell in ipairs(drm_pill_cells(drm.pill)) do
        if drm_in_bounds(cell.x, cell.y) then drm.grid[cell.y][cell.x] = {c = cell.c, t = TYPE_PILL} end
    end
    drm.pill = nil
end
local function drm_spawn_viruses(count)
    local placed, tries = 0, 0
    while placed < count and tries < 400 do
        tries = tries + 1
        local x, y = math.random(1, DRM_W), math.random(7, DRM_H)
        if drm.grid[y][x].c == COL_EMPTY then
            drm.grid[y][x] = {c = drm_rand_color(), t = TYPE_VIRUS} placed = placed + 1
        end
    end
    drm.virusesLeft = placed
end
local function drm_count_viruses()
    local n = 0
    for y = 1, DRM_H do for x = 1, DRM_W do if drm.grid[y][x].t == TYPE_VIRUS then n = n + 1 end end end
    drm.virusesLeft = n return n
end
local function drm_apply_gravity()
    local moved = true
    while moved do
        moved = false
        for y = DRM_H - 1, 1, -1 do
            for x = 1, DRM_W do
                local cell = drm.grid[y][x]
                if cell.c ~= COL_EMPTY and cell.t == TYPE_PILL and drm.grid[y + 1][x].c == COL_EMPTY then
                    drm.grid[y + 1][x] = {c = cell.c, t = TYPE_PILL}
                    drm.grid[y][x] = {c = COL_EMPTY, t = 0} moved = true
                end
            end
        end
    end
end
local function drm_clear_matches()
    local mark = {}
    for y = 1, DRM_H do mark[y] = {} for x = 1, DRM_W do mark[y][x] = false end end
    for y = 1, DRM_H do
        local x = 1
        while x <= DRM_W do
            local col = drm.grid[y][x].c
            if col ~= COL_EMPTY then
                local len = 1
                while x + len <= DRM_W and drm.grid[y][x + len].c == col do len = len + 1 end
                if len >= 4 then for i = 0, len - 1 do mark[y][x + i] = true end end
                x = x + len
            else x = x + 1 end
        end
    end
    for x = 1, DRM_W do
        local y = 1
        while y <= DRM_H do
            local col = drm.grid[y][x].c
            if col ~= COL_EMPTY then
                local len = 1
                while y + len <= DRM_H and drm.grid[y + len][x].c == col do len = len + 1 end
                if len >= 4 then for i = 0, len - 1 do mark[y + i][x] = true end end
                y = y + len
            else y = y + 1 end
        end
    end
    local cleared, viruses = 0, 0
    for y = 1, DRM_H do for x = 1, DRM_W do
        if mark[y][x] then
            if drm.grid[y][x].t == TYPE_VIRUS then viruses = viruses + 1 end
            drm.grid[y][x] = {c = COL_EMPTY, t = 0} cleared = cleared + 1
        end
    end end
    if cleared > 0 then
        drm.score = drm.score + cleared * 10 + viruses * 50
        drm.clearFlash = 8 drm_apply_gravity() drm_count_viruses() return true
    end
    return false
end
local function drm_resolve_board()
    local safety = 0
    while drm_clear_matches() and safety < 20 do safety = safety + 1 end
end
local function drm_spawn_pill()
    if not drm.nextPill then drm.nextPill = drm_make_pill() end
    drm.pill = {x = 4, y = 1, rot = 0, c1 = drm.nextPill.c1, c2 = drm.nextPill.c2}
    drm.nextPill = drm_make_pill()
    if not drm_can_place(drm.pill) then drm.alive = false drm.pill = nil end
end
local function drm_setup_level(level)
    drm.grid = drm_empty_grid() drm.level = level drm.alive = true
    drm.wonLevel = false drm.wonGame = false drm.fallTimer = 0 drm.clearFlash = 0
    if level == 1 then drm.fallDelay = 28 drm_spawn_viruses(12) else drm.fallDelay = 18 drm_spawn_viruses(22) end
    drm.nextPill = drm_make_pill() drm_spawn_pill()
end
local function drm_start()
    stop_all_minigames() gGlobalSyncTable.drmPlaying = true drm.score = 0
    drm_setup_level(1) TERM_OPEN = true term_print("BOWSER FIGHT")
end
local function drm_stop() gGlobalSyncTable.drmPlaying = false end
local function drm_try_move(dx, dy, drot)
    if not drm.pill or not drm.alive then return false end
    local np = {x = drm.pill.x + (dx or 0), y = drm.pill.y + (dy or 0), rot = (drm.pill.rot + (drot or 0)) % 4, c1 = drm.pill.c1, c2 = drm.pill.c2}
    if drm_can_place(np) then drm.pill = np return true end
    return false
end
local function drm_update(m)
    if not drm.alive then
        local c = m.controller
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then drm_setup_level(drm.level) end
        return
    end
    if drm.wonLevel then
        local c = m.controller
        if c and (c.buttonPressed & A_BUTTON) ~= 0 and drm.level == 1 then drm_setup_level(2) end
        return
    end
    if drm.inputCD > 0 then drm.inputCD = drm.inputCD - 1 end
    local c = m.controller
    if c and drm.inputCD <= 0 then
        if (c.buttonPressed & L_JPAD) ~= 0 or c.stickX < -40 then drm_try_move(-1, 0, 0) drm.inputCD = 4
        elseif (c.buttonPressed & R_JPAD) ~= 0 or c.stickX > 40 then drm_try_move(1, 0, 0) drm.inputCD = 4 end
        if (c.buttonPressed & A_BUTTON) ~= 0 or (c.buttonPressed & B_BUTTON) ~= 0 then drm_try_move(0, 0, 1) drm.inputCD = 6 end
        if (c.buttonDown & D_JPAD) ~= 0 or c.stickY < -40 then if drm_try_move(0, 1, 0) then drm.score = drm.score + 1 end drm.inputCD = 2 end
    end
    if drm.clearFlash > 0 then drm.clearFlash = drm.clearFlash - 1 return end
    drm.fallTimer = drm.fallTimer + 1
    if drm.fallTimer >= drm.fallDelay and drm.pill then
        drm.fallTimer = 0
        if not drm_try_move(0, 1, 0) then
            drm_lock_pill() drm_resolve_board()
            if drm_count_viruses() <= 0 then
                drm.wonLevel = true
                if drm.level >= 2 then drm.wonGame = true end
            else drm_spawn_pill() end
        end
    end
end

local function dk_reset()
    dk.x = 36 dk.y = 248 dk.vx = 0 dk.vy = 0
    dk.onGround = false dk.onLadder = false dk.facing = 1
    dk.alive = true dk.win = false dk.barrels = {} dk.spawnTimer = 0
end
local function dk_start()
    stop_all_minigames() gGlobalSyncTable.dkPlaying = true
    dk.lives = 3 dk.score = 0 dk_reset() TERM_OPEN = true term_print("DONKEY KONG")
end
local function dk_stop() gGlobalSyncTable.dkPlaying = false end
local function dk_find_ladder()
    for i = 1, #dkLadders do
        local l = dkLadders[i]
        local cx = dk.x + dk.w * 0.5
        if cx > l.x - 4 and cx < l.x + 16 and dk.y + dk.h > l.y - 6 and dk.y < l.y + l.h + 8 then return l end
    end
    return nil
end
local function dk_update(m)
    if dk.win or not dk.alive then
        local c = m.controller
        if not dk.alive and c and (c.buttonPressed & A_BUTTON) ~= 0 then
            if dk.lives > 0 then dk_reset() else dk.lives = 3 dk.score = 0 dk_reset() end
        end
        return
    end
    local c = m.controller
    local left, right, up, down, jump = false, false, false, false, false
    if c then
        if (c.buttonDown & L_JPAD) ~= 0 or c.stickX < -18 then left = true end
        if (c.buttonDown & R_JPAD) ~= 0 or c.stickX > 18 then right = true end
        if (c.buttonDown & U_JPAD) ~= 0 or c.stickY > 18 then up = true end
        if (c.buttonDown & D_JPAD) ~= 0 or c.stickY < -18 then down = true end
        if (c.buttonPressed & A_BUTTON) ~= 0 then jump = true end
    end
    local ladder = dk_find_ladder()
    if ladder and (up or down) then dk.onLadder = true dk.x = ladder.x + 1 dk.vx = 0 dk.vy = 0 end
    if dk.onLadder then
        ladder = dk_find_ladder()
        if not ladder then dk.onLadder = false
        else
            if up then dk.y = dk.y - 2.5 end if down then dk.y = dk.y + 2.5 end
            if dk.y + dk.h <= ladder.y + 4 and up then dk.y = ladder.y - dk.h dk.onLadder = false end
            if left or right then dk.onLadder = false end
        end
    end
    if not dk.onLadder then
        dk.vx = 0
        if left then dk.vx = -2.6 dk.facing = -1 end
        if right then dk.vx = 2.6 dk.facing = 1 end
        if jump and dk.onGround then dk.vy = -8 dk.onGround = false end
        dk.vy = math.min(9, dk.vy + 0.38)
    end
    dk.x = clamp(dk.x + dk.vx, 16, 310) dk.y = dk.y + dk.vy dk.onGround = false
    if not dk.onLadder then
        for i = 1, #dkFloors do
            local f = dkFloors[i]
            if rects_overlap(dk.x, dk.y, dk.w, dk.h, f.x, f.y, f.w, f.h) and dk.vy >= 0 then
                dk.y = f.y - dk.h dk.vy = 0 dk.onGround = true
            end
        end
    end
    if dk.y > 310 then dk.alive = false dk.lives = dk.lives - 1 end
    if dk.y < 48 and dk.x > 220 then dk.win = true dk.score = dk.score + 500 end
    dk.spawnTimer = dk.spawnTimer + 1
    if dk.spawnTimer > 50 then
        dk.spawnTimer = 0
        table.insert(dk.barrels, {x = 78, y = 28, vx = 2.1, vy = 0, w = 12, h = 12, floorIndex = 1, falling = false})
    end
    for i = #dk.barrels, 1, -1 do
        local b = dk.barrels[i]
        local floor = dkFloors[b.floorIndex or 1]
        if b.falling then
            b.vy = math.min(6, b.vy + 0.35) b.y = b.y + b.vy
            local nf = dkFloors[(b.floorIndex or 1) + 1]
            if nf and b.y + b.h >= nf.y and b.x + b.w > nf.x and b.x < nf.x + nf.w then
                b.y = nf.y - b.h b.vy = 0 b.falling = false b.floorIndex = (b.floorIndex or 1) + 1
                b.vx = (nf.dir or 1) * math.abs(b.vx)
            end
            if b.y > 330 then table.remove(dk.barrels, i) end
        elseif floor then
            b.vx = (floor.dir or 1) * math.abs(b.vx) b.x = b.x + b.vx b.y = floor.y - b.h
            if b.x < floor.x - 2 or b.x + b.w > floor.x + floor.w + 2 then b.falling = true b.vy = 1 end
        end
        if rects_overlap(dk.x, dk.y, dk.w, dk.h, b.x, b.y, b.w, b.h) then
            dk.alive = false dk.lives = dk.lives - 1
        end
    end
end

local function poker_new_deck()
    local deck = {}
    for s = 1, 4 do for r = 1, 13 do
        table.insert(deck, {rank = r, suit = s, rankName = RANKS[r], suitName = SUITS[s], suitFull = SUIT_FULL[s]})
    end end
    for i = #deck, 2, -1 do local j = math.random(i) deck[i], deck[j] = deck[j], deck[i] end
    return deck
end
local function poker_eval_hand(hand)
    if not hand or #hand < 5 then return "NOTHING", 0 end
    local ranks, suits = {}, {}
    for i = 1, 5 do ranks[i] = hand[i].rank suits[i] = hand[i].suit end
    table.sort(ranks)
    local isFlush = true
    for i = 2, 5 do if suits[i] ~= suits[1] then isFlush = false break end end
    local isStraight = true
    for i = 2, 5 do if ranks[i] ~= ranks[1] + i - 1 then isStraight = false break end end
    if ranks[1] == 1 and ranks[2] == 10 and ranks[3] == 11 and ranks[4] == 12 and ranks[5] == 13 then isStraight = true end
    local counts = {}
    for i = 1, 5 do counts[ranks[i]] = (counts[ranks[i]] or 0) + 1 end
    local pairCount, three, four, highPair = 0, 0, 0, 0
    for r, cnt in pairs(counts) do
        if cnt == 2 then pairCount = pairCount + 1 if r == 1 or r > highPair then highPair = r end end
        if cnt == 3 then three = 1 end if cnt == 4 then four = 1 end
    end
    if isStraight and isFlush and ranks[1] == 1 and ranks[5] == 13 then return "ROYAL FLUSH", 250 end
    if isStraight and isFlush then return "STRAIGHT FLUSH", 50 end
    if four == 1 then return "FOUR OF A KIND", 25 end
    if three == 1 and pairCount == 1 then return "FULL HOUSE", 9 end
    if isFlush then return "FLUSH", 6 end
    if isStraight then return "STRAIGHT", 4 end
    if three == 1 then return "THREE OF A KIND", 3 end
    if pairCount == 2 then return "TWO PAIR", 2 end
    if pairCount == 1 and (highPair >= 11 or highPair == 1) then return "JACKS OR BETTER", 1 end
    return "NOTHING", 0
end
local function poker_start()
    stop_all_minigames() gGlobalSyncTable.pokerPlaying = true
    poker.credits = 100 poker.bet = 5 poker.hand = {} poker.held = {false, false, false, false, false}
    poker.phase = "bet" poker.msg = "A: Deal  Up/Down: Bet" poker.cursor = 1 TERM_OPEN = true
end
local function poker_stop() gGlobalSyncTable.pokerPlaying = false end
local function poker_deal()
    if poker.credits < poker.bet then poker.msg = "Not enough credits!" return end
    poker.credits = poker.credits - poker.bet poker.deck = poker_new_deck() poker.hand = {}
    for i = 1, 5 do table.insert(poker.hand, table.remove(poker.deck)) end
    poker.held = {false, false, false, false, false} poker.phase = "hold"
    poker.msg = "L/R select  A hold  B draw" poker.cursor = 1
end
local function poker_draw()
    if not poker.deck then return end
    for i = 1, 5 do if not poker.held[i] and #poker.deck > 0 then poker.hand[i] = table.remove(poker.deck) end end
    local name, mult = poker_eval_hand(poker.hand)
    poker.winAmount = mult * poker.bet poker.credits = poker.credits + poker.winAmount
    poker.phase = "result" poker.msg = mult > 0 and (name .. "! +" .. poker.winAmount) or "No win..."
end
local function poker_update(m)
    local c = m.controller if not c then return end
    if poker.phase == "bet" then
        if (c.buttonPressed & U_JPAD) ~= 0 then poker.bet = math.min(50, poker.bet + 5) end
        if (c.buttonPressed & D_JPAD) ~= 0 then poker.bet = math.max(5, poker.bet - 5) end
        if (c.buttonPressed & A_BUTTON) ~= 0 then poker_deal() end
    elseif poker.phase == "hold" then
        if (c.buttonPressed & L_JPAD) ~= 0 then poker.cursor = poker.cursor - 1 if poker.cursor < 1 then poker.cursor = 5 end end
        if (c.buttonPressed & R_JPAD) ~= 0 then poker.cursor = poker.cursor + 1 if poker.cursor > 5 then poker.cursor = 1 end end
        if (c.buttonPressed & A_BUTTON) ~= 0 then poker.held[poker.cursor] = not poker.held[poker.cursor] end
        if (c.buttonPressed & B_BUTTON) ~= 0 then poker_draw() end
    elseif poker.phase == "result" then
        if (c.buttonPressed & A_BUTTON) ~= 0 then poker.phase = "bet" poker.msg = "A: Deal  Up/Down: Bet" end
    end
end

local function detective_gen_round()
    detective.grid = {} detective.targetType = math.random(1, 3)
    local total = detective.cols * detective.rows
    local numTargets = math.min(8, 3 + detective.round)
    local indices = {}
    for i = 1, total do indices[i] = i end
    for i = total, 2, -1 do local j = math.random(i) indices[i], indices[j] = indices[j], indices[i] end
    local targetSet = {}
    for i = 1, numTargets do targetSet[indices[i]] = true end
    for i = 1, total do
        if targetSet[i] then detective.grid[i] = {type = detective.targetType, found = false}
        else
            local t = math.random(1, 6)
            while t == detective.targetType do t = math.random(1, 6) end
            detective.grid[i] = {type = t, found = false}
        end
    end
    detective.targetsLeft = numTargets detective.cursor = 1
    detective.msg = "Find all " .. FACE_NAMES[detective.targetType] .. "!"
end
local function detective_start()
    stop_all_minigames() gGlobalSyncTable.detectivePlaying = true
    detective.score = 0 detective.mistakes = 0 detective.round = 1
    detective.alive = true detective.won = false detective_gen_round() TERM_OPEN = true
end
local function detective_stop() gGlobalSyncTable.detectivePlaying = false end
local function detective_update(m)
    if detective.won or not detective.alive then
        local c = m.controller
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then
            detective.score = 0 detective.mistakes = 0 detective.round = 1
            detective.alive = true detective.won = false detective_gen_round()
        end
        return
    end
    local c = m.controller if not c then return end
    local cols = detective.cols
    if (c.buttonPressed & L_JPAD) ~= 0 then detective.cursor = detective.cursor - 1 end
    if (c.buttonPressed & R_JPAD) ~= 0 then detective.cursor = detective.cursor + 1 end
    if (c.buttonPressed & U_JPAD) ~= 0 then detective.cursor = detective.cursor - cols end
    if (c.buttonPressed & D_JPAD) ~= 0 then detective.cursor = detective.cursor + cols end
    detective.cursor = clamp(detective.cursor, 1, cols * detective.rows)
    if (c.buttonPressed & A_BUTTON) ~= 0 then
        local cell = detective.grid[detective.cursor]
        if cell and not cell.found then
            if cell.type == detective.targetType then
                cell.found = true detective.targetsLeft = detective.targetsLeft - 1 detective.score = detective.score + 50
                if detective.targetsLeft <= 0 then
                    detective.round = detective.round + 1
                    if detective.round > detective.maxRounds then detective.won = true detective.msg = "CASE CLOSED!"
                    else detective_gen_round() end
                end
            else
                detective.mistakes = detective.mistakes + 1
                if detective.mistakes >= detective.maxMistakes then detective.alive = false detective.msg = "Failed..." end
            end
        end
    end
end

local function snake_init_state()
    gGlobalSyncTable.snakeAlive = true gGlobalSyncTable.snakeDir = 1
    gGlobalSyncTable.snakeScore = 0 gGlobalSyncTable.snakeFoodX = 20
    gGlobalSyncTable.snakeFoodY = 7 gGlobalSyncTable.snakeBody = "12,7;11,7;10,7;9,7"
end
local function snake_parse_body()
    local body = {}
    local str = gGlobalSyncTable.snakeBody or "12,7;11,7;10,7;9,7"
    for part in string.gmatch(str, "[^;]+") do
        local x, y = string.match(part, "(%d+),(%d+)")
        if x and y then table.insert(body, {x = tonumber(x), y = tonumber(y)}) end
    end
    return body
end
local function snake_serialize_body(body)
    local parts = {}
    for i = 1, #body do table.insert(parts, body[i].x .. "," .. body[i].y) end
    return table.concat(parts, ";")
end
local function snake_spawn_food(body)
    for _ = 1, 100 do
        local fx, fy = math.random(0, GRID_W - 1), math.random(0, GRID_H - 1)
        local ok = true
        for i = 1, #body do if body[i].x == fx and body[i].y == fy then ok = false break end end
        if ok then gGlobalSyncTable.snakeFoodX = fx gGlobalSyncTable.snakeFoodY = fy return end
    end
end
local function snake_start()
    if not network_is_server() then term_print("Host only") return end
    stop_all_minigames() gGlobalSyncTable.snakePlaying = true snake_init_state() TERM_OPEN = true
end
local function snake_stop() gGlobalSyncTable.snakePlaying = false end
local function snake_set_dir(d)
    if not gGlobalSyncTable.snakeAlive then return end
    local c = gGlobalSyncTable.snakeDir or 1
    if (c == 1 and d == 3) or (c == 3 and d == 1) or (c == 2 and d == 4) or (c == 4 and d == 2) then return end
    gGlobalSyncTable.snakeDir = d
end
local function snake_tick()
    if not gGlobalSyncTable.snakePlaying or not gGlobalSyncTable.snakeAlive or not network_is_server() then return end
    local body = snake_parse_body() if #body == 0 then return end
    local dir = gGlobalSyncTable.snakeDir or 1
    local nx, ny = body[1].x, body[1].y
    if dir == 1 then nx = nx + 1 elseif dir == 2 then ny = ny + 1
    elseif dir == 3 then nx = nx - 1 elseif dir == 4 then ny = ny - 1 end
    if nx < 0 or ny < 0 or nx >= GRID_W or ny >= GRID_H then gGlobalSyncTable.snakeAlive = false return end
    for i = 1, #body do if body[i].x == nx and body[i].y == ny then gGlobalSyncTable.snakeAlive = false return end end
    table.insert(body, 1, {x = nx, y = ny})
    if nx == (gGlobalSyncTable.snakeFoodX or 0) and ny == (gGlobalSyncTable.snakeFoodY or 0) then
        gGlobalSyncTable.snakeScore = (gGlobalSyncTable.snakeScore or 0) + 1 snake_spawn_food(body)
    else table.remove(body) end
    gGlobalSyncTable.snakeBody = snake_serialize_body(body)
end

local function plat_reset_full()
    plat.x = 48 plat.y = 200 plat.vx = 0 plat.vy = 0
    plat.onGround = false plat.facing = 1 plat.score = 0
    plat.alive = true plat.win = false plat.cameraX = 0
    plat.coyote = 0 plat.jumpBuf = 0 plat.anim = 0 plat.lives = 3
    for i = 1, #coins do coins[i].got = false end
    for i = 1, #enemies do
        enemies[i].alive = true
        enemies[i].x = ({260, 500, 650, 820})[i]
        enemies[i].vx = ({1.15, -1.05, 1.2, -1.1})[i]
    end
end
local function plat_start()
    stop_all_minigames() gGlobalSyncTable.platPlaying = true plat_reset_full() TERM_OPEN = true
end
local function plat_stop() gGlobalSyncTable.platPlaying = false end
local function plat_update(m)
    if plat.win then return end
    if not plat.alive then
        local c = m.controller
        if c and (c.buttonPressed & A_BUTTON) ~= 0 then
            if plat.lives > 0 then plat.x = 48 plat.y = 200 plat.vx = 0 plat.vy = 0 plat.alive = true
            else plat_reset_full() end
        end
        return
    end
    local c = m.controller
    local left, right, jumpPress, jumpHold = false, false, false, false
    if c then
        if (c.buttonDown & L_JPAD) ~= 0 or c.stickX < -18 then left = true end
        if (c.buttonDown & R_JPAD) ~= 0 or c.stickX > 18 then right = true end
        if (c.buttonPressed & A_BUTTON) ~= 0 then jumpPress = true end
        if (c.buttonDown & A_BUTTON) ~= 0 then jumpHold = true end
    end
    if jumpPress then plat.jumpBuf = JUMP_BUFFER_MAX end
    if plat.onGround then plat.coyote = COYOTE_MAX end
    plat.vx = 0
    if left then plat.vx = -PLAT_MOVE_SPEED plat.facing = -1 end
    if right then plat.vx = PLAT_MOVE_SPEED plat.facing = 1 end
    if left or right then plat.anim = plat.anim + 1 end
    if plat.jumpBuf > 0 and plat.coyote > 0 then
        plat.vy = PLAT_JUMP plat.onGround = false plat.coyote = 0 plat.jumpBuf = 0
    end
    if not plat.onGround and jumpHold and plat.vy < 0 then plat.vy = plat.vy + PLAT_JUMP_HOLD end
    plat.vy = math.min(13, plat.vy + PLAT_GRAVITY)
    if plat.coyote > 0 then plat.coyote = plat.coyote - 1 end
    if plat.jumpBuf > 0 then plat.jumpBuf = plat.jumpBuf - 1 end
    plat.x = plat.x + plat.vx plat.y = plat.y + plat.vy plat.onGround = false
    for i = 1, #platforms do
        local p = platforms[i]
        if rects_overlap(plat.x, plat.y, plat.w, plat.h, p.x, p.y, p.w, p.h) then
            if plat.vy >= 0 and (plat.y - plat.vy) + plat.h <= p.y + 5 then
                plat.y = p.y - plat.h plat.vy = 0 plat.onGround = true
            end
        end
    end
    if plat.y > 360 then plat.alive = false plat.lives = plat.lives - 1 end
    for i = 1, #coins do
        if not coins[i].got and rects_overlap(plat.x, plat.y, plat.w, plat.h, coins[i].x, coins[i].y, 12, 12) then
            coins[i].got = true plat.score = plat.score + 1
        end
    end
    for i = 1, #enemies do
        local e = enemies[i]
        if e.alive then
            e.x = e.x + e.vx
            if e.x < 40 or e.x > PLAT_WORLD_W - 80 then e.vx = -e.vx end
            if rects_overlap(plat.x, plat.y, plat.w, plat.h, e.x, e.y, e.w, e.h) then
                if plat.vy > 0 then e.alive = false plat.vy = -7.5
                else plat.alive = false plat.lives = plat.lives - 1 end
            end
        end
    end
    if rects_overlap(plat.x, plat.y, plat.w, plat.h, goal.x, goal.y, goal.w, goal.h) then plat.win = true end
    plat.cameraX = clamp(plat.cameraX + (plat.x - PLAT_VIEW_W * 0.36 - plat.cameraX) * 0.13, 0, PLAT_WORLD_W - PLAT_VIEW_W)
end

------------------------------------------------------------
-- COMMANDS
------------------------------------------------------------
local function process_command(raw)
    local cmd = string.lower(string.gsub(raw or "", "^%s*(.-)%s*$", "%1"))
    if cmd == "" then return end
    local args = {}
    for word in string.gmatch(cmd, "%S+") do table.insert(args, word) end
    local main, sub = args[1] or "", args[2]

    if main == "help" or main == "?" then
        term_print("          SM64 TERMINAL")
        term_print("")
        term_print("     --- MINIGAMES ---")
        term_print("  2d   snake   bowserfight   dk")
        term_print("  luigi   detective   pinball")
        term_print("  lakitu   baseball   boo")
        term_print("")
        term_print("     --- WORLD ---")
        term_print("  spawn <obj>   power <p> <type>")
        term_print("  god   moonjump   speed <n>")
        term_print("  size <n>   heal   coins <n>")
        term_print("  lives <n>   tp <p>   players")
        term_print("")
        term_print("     --- SYSTEM ---")
        term_print("  theme <1-5>   status   clear")
        term_print("  close")
    elseif main == "theme" then
        local t = tonumber(args[2])
        if t and t >= 1 and t <= 5 then
            TERM_THEME = t
            term_print("Theme: " .. THEME_NAMES[TERM_THEME])
        else
            term_print("Themes: 1 Green  2 CRT  3 VHS")
            term_print("        4 Purple  5 N64")
            term_print("Current: " .. THEME_NAMES[TERM_THEME])
        end
    elseif main == "clear" or main == "cls" then term_clear()
    elseif main == "2d" then if sub == "stop" then plat_stop() else plat_start() end
    elseif main == "snake" then if sub == "stop" then snake_stop() else snake_start() end
    elseif main == "bowserfight" or main == "bowser" then if sub == "stop" then drm_stop() else drm_start() end
    elseif main == "dk" then if sub == "stop" then dk_stop() else dk_start() end
    elseif main == "luigi" or main == "poker" then if sub == "stop" then poker_stop() else poker_start() end
    elseif main == "detective" then if sub == "stop" then detective_stop() else detective_start() end
    elseif main == "pinball" or main == "pin" then if sub == "stop" then pin_stop() else pin_start() end
    elseif main == "lakitu" or main == "launch" then if sub == "stop" then lak_stop() else lak_start() end
    elseif main == "baseball" or main == "bb" then if sub == "stop" then bb_stop() else bb_start() end
    elseif main == "boo" or main == "hide" then if sub == "stop" then boo_stop() else boo_start() end
    elseif main == "spawn" then
        local name = args[2]
        if not name then term_print("spawn <1up|coin|star|goomba|...>") return end
        local entry = SPAWN_LIST[name]
        if not entry then term_print("Unknown object") return end
        local m = gMarioStates[0]
        if m then
            local yaw = m.faceAngle.y or 0
            local x = m.pos.x + sins(yaw) * 150
            local y = m.pos.y + 50
            local z = m.pos.z + coss(yaw) * 150
            local ok = pcall(function() spawn_sync_object(entry.bhv, entry.model, x, y, z, nil) end)
            term_print(ok and ("Spawned " .. name) or "Spawn failed")
        end
    elseif main == "power" then
        local m = get_mario_by_name(args[2] or "me")
        local ptype = string.lower(args[3] or "")
        if not m then term_print("Player not found") return end
        if ptype == "metal" then m.flags = m.flags | MARIO_METAL_CAP m.capTimer = 600 term_print("Metal")
        elseif ptype == "vanish" then m.flags = m.flags | MARIO_VANISH_CAP m.capTimer = 600 term_print("Vanish")
        elseif ptype == "wing" then m.flags = m.flags | MARIO_WING_CAP m.capTimer = 600 term_print("Wing")
        elseif ptype == "off" then m.flags = m.flags & ~MARIO_METAL_CAP & ~MARIO_VANISH_CAP & ~MARIO_WING_CAP m.capTimer = 0 term_print("Caps off")
        else term_print("power <p> metal|vanish|wing|off") end
    elseif main == "god" then godMode = not godMode term_print("God " .. (godMode and "ON" or "OFF"))
    elseif main == "moonjump" or main == "moon" then moonJump = not moonJump term_print("Moonjump " .. (moonJump and "ON" or "OFF"))
    elseif main == "speed" then speedMul = clamp(tonumber(args[2]) or 1, 0.25, 8) term_print("Speed " .. speedMul)
    elseif main == "size" then
        sizeMul = clamp(tonumber(args[2]) or 1, 0.2, 5)
        local m = gMarioStates[0]
        if m and m.marioObj then
            m.marioObj.header.gfx.scale.x = sizeMul
            m.marioObj.header.gfx.scale.y = sizeMul
            m.marioObj.header.gfx.scale.z = sizeMul
        end
        term_print("Size " .. sizeMul)
    elseif main == "heal" then
        local m = gMarioStates[0]
        if m then m.health = 0x880 m.hurtCounter = 0 term_print("Healed") end
    elseif main == "coins" then
        local m = gMarioStates[0]
        if m and tonumber(args[2]) then m.numCoins = tonumber(args[2]) term_print("Coins set") end
    elseif main == "lives" then
        local m = gMarioStates[0]
        if m and tonumber(args[2]) then m.numLives = tonumber(args[2]) term_print("Lives set") end
    elseif main == "tp" then
        local m, o = gMarioStates[0], get_mario_by_name(args[2] or "")
        if m and o then m.pos.x = o.pos.x m.pos.y = o.pos.y + 100 m.pos.z = o.pos.z term_print("Teleported")
        else term_print("Player not found") end
    elseif main == "players" then
        for i = 0, (MAX_PLAYERS or 16) - 1 do
            local np = gNetworkPlayers[i]
            if np and np.connected then term_print(i .. ": " .. (np.name or "?")) end
        end
    elseif main == "status" then
        term_print(any_minigame() and "IN MINIGAME" or ("IDLE  theme=" .. THEME_NAMES[TERM_THEME]))
    elseif main == "close" or main == "exit" then
        TERM_OPEN = false stop_all_minigames()
    else term_print("Unknown: " .. main) end
end

local function term_command(msg)
    msg = msg or ""
    if msg == "" or msg == "toggle" then
        TERM_OPEN = not TERM_OPEN
        if TERM_OPEN then term_print("Terminal online. Type help") end
        return true
    end
    if not TERM_OPEN then TERM_OPEN = true end
    process_command(msg)
    return true
end

------------------------------------------------------------
-- HOOKS
------------------------------------------------------------
local function freeze_mario(m)
    m.vel.x = 0 m.vel.y = 0 m.vel.z = 0 m.forwardVel = 0 m.hurtCounter = 0
    if m.action ~= ACT_IDLE then set_mario_action(m, ACT_IDLE, 0) end
end
local function mario_update(m)
    if m.playerIndex ~= 0 then return end
    if not any_minigame() then
        if godMode then m.health = 0x880 m.hurtCounter = 0 end
        if moonJump and m.controller and (m.controller.buttonDown & A_BUTTON) ~= 0 then
            if m.vel.y < 25 then m.vel.y = m.vel.y + 2.5 end
        end
        if sizeMul ~= 1.0 and m.marioObj then
            m.marioObj.header.gfx.scale.x = sizeMul
            m.marioObj.header.gfx.scale.y = sizeMul
            m.marioObj.header.gfx.scale.z = sizeMul
        end
    else
        freeze_mario(m)
        if gGlobalSyncTable.snakePlaying then
            local c = m.controller
            if c then
                if (c.buttonPressed & U_JPAD) ~= 0 or c.stickY > 40 then snake_set_dir(4)
                elseif (c.buttonPressed & D_JPAD) ~= 0 or c.stickY < -40 then snake_set_dir(2)
                elseif (c.buttonPressed & L_JPAD) ~= 0 or c.stickX < -40 then snake_set_dir(3)
                elseif (c.buttonPressed & R_JPAD) ~= 0 or c.stickX > 40 then snake_set_dir(1) end
            end
        elseif gGlobalSyncTable.platPlaying then plat_update(m)
        elseif gGlobalSyncTable.drmPlaying then drm_update(m)
        elseif gGlobalSyncTable.dkPlaying then dk_update(m)
        elseif gGlobalSyncTable.pokerPlaying then poker_update(m)
        elseif gGlobalSyncTable.detectivePlaying then detective_update(m)
        elseif gGlobalSyncTable.pinPlaying then pin_update(m)
        elseif gGlobalSyncTable.lakPlaying then lak_update(m)
        elseif gGlobalSyncTable.bbPlaying then bb_update(m)
        elseif gGlobalSyncTable.booPlaying then boo_update(m) end
    end
end
local function before_set_mario_action(m, action, arg)
    if m.playerIndex == 0 and any_minigame() then return 1 end
end
local function update()
    if gGlobalSyncTable.snakePlaying and network_is_server() then
        snakeMoveTimer = snakeMoveTimer + 1
        if snakeMoveTimer >= 5 then snakeMoveTimer = 0 snake_tick() end
    end
    if any_minigame() and not TERM_OPEN then TERM_OPEN = true end
end

------------------------------------------------------------
-- DRAW (minigames use simple draws; shell is themed)
------------------------------------------------------------
local function draw_mario_sprite(x, y, w, h, facing, a)
    draw_rect_a(x + 1, y + h - 5, 5, 5, 90, 50, 20, a)
    draw_rect_a(x + w - 6, y + h - 5, 5, 5, 90, 50, 20, a)
    draw_rect_a(x + 2, y + 10, w - 4, h - 14, 40, 60, 200, a)
    draw_rect_a(x, y + 6, w, 10, 220, 40, 40, a)
    draw_rect_a(x + 2, y + 2, w - 4, 8, 255, 200, 160, a)
    draw_rect_a(x, y, w, 5, 220, 30, 30, a)
end

local function draw_centered_text(text, cx, y, scale, r, g, b, a)
    local w = djui_hud_measure_text(text) * scale
    djui_hud_set_color(r, g, b, a)
    djui_hud_print_text(text, cx - w * 0.5, y, scale)
end

-- Minigame draw stubs (compact)
local function draw_lakitu(tx, ty, tw, th, a)
    local ox, oy = tx + 40, ty + 50
    draw_rect_a(ox, oy, 520, 320, 20, 30, 70, a)
    draw_rect_a(ox, oy + 280, 520, 40, 50, 120, 40, a)
    local scale = 0.55
    for i = 1, #lak.coins do
        local c = lak.coins[i]
        if not c.got then draw_rect_a(ox + c.x * scale, oy + c.y * scale, 10, 10, 255, 220, 40, a) end
    end
    draw_rect_a(ox + lak.x * scale - 10, oy + lak.y * scale - 6, 28, 12, 240, 240, 255, a)
    draw_rect_a(ox + lak.x * scale - 4, oy + lak.y * scale - 18, 16, 14, 255, 220, 80, a)
    djui_hud_set_color(180, 255, 200, a)
    if lak.phase == "aim" then djui_hud_print_text("AIM  Up/Down   A: power", tx + 30, ty + th - 32, 0.40)
    elseif lak.phase == "power" then
        draw_rect_a(ox + 20, oy + 20, 120, 16, 40, 40, 40, a)
        draw_rect_a(ox + 22, oy + 22, lak.power * 1.16, 12, 255, to_int(100 + lak.power), 40, a)
        djui_hud_print_text("POWER  A: LAUNCH", tx + 30, ty + th - 32, 0.40)
    elseif lak.phase == "fly" then djui_hud_print_text("FLYING  Dist " .. to_int(lak.dist), tx + 30, ty + th - 32, 0.40)
    else djui_hud_print_text("DIST " .. to_int(lak.dist) .. "  BEST " .. lak.best .. "  A: retry", tx + 30, ty + th - 32, 0.38) end
end
local function draw_baseball(tx, ty, tw, th, a)
    local ox, oy = tx + 60, ty + 55
    draw_rect_a(ox, oy, 480, 320, 35, 90, 40, a)
    draw_rect_a(ox + 200, oy + 250, 18, 18, 220, 200, 160, a)
    draw_rect_a(ox + 95, oy + 230, 14, 22, 230, 40, 40, a)
    draw_rect_a(ox + 205, oy + 155, 12, 18, 50, 50, 200, a)
    draw_rect_a(ox + bb.ballX * 0.9 - 4, oy + bb.ballY * 0.85 - 4, 9, 9, 255, 255, 255, a)
    djui_hud_set_color(255, 230, 100, a)
    djui_hud_print_text("SCORE " .. bb.score .. "  OUTS " .. bb.outs .. "/3", tx + 30, ty + 12, 0.42)
    djui_hud_set_color(200, 255, 220, a)
    djui_hud_print_text(bb.msg, tx + 30, ty + th - 34, 0.40)
end
local function draw_boo_game(tx, ty, tw, th, a)
    local ox, oy = tx + 40, ty + 50
    draw_rect_a(ox, oy, 500, 360, 15, 12, 28, a)
    if booGame.phase == "hide" then
        draw_centered_text("Boos are hiding...", ox + 250, oy + 160, 0.55, 180, 160, 255, a)
        local bar = booGame.timer / booGame.hideTime
        draw_rect_a(ox + 100, oy + 200, 300, 16, 40, 40, 40, a)
        draw_rect_a(ox + 102, oy + 202, 296 * bar, 12, 150, 100, 255, a)
    else
        for i = 1, #booGame.boos do
            local b = booGame.boos[i]
            local bx, by = ox + b.x, oy + b.y
            if b.found then
                draw_rect_a(bx - 10, by - 12, 24, 22, 230, 230, 245, a)
            else
                local d = math.sqrt(dist2(booGame.playerX, booGame.playerY, b.x, b.y))
                if d < 70 then
                    local wob = math.sin(b.wobble) * 2
                    draw_rect_a(bx - 4, by - 4 + wob, 5, 5, 255, 80, 80, a)
                    draw_rect_a(bx + 4, by - 4 + wob, 5, 5, 255, 80, 80, a)
                end
            end
        end
        draw_rect_a(ox + booGame.playerX - 7, oy + booGame.playerY - 10, 14, 20, 230, 40, 40, a)
    end
    djui_hud_set_color(200, 180, 255, a)
    djui_hud_print_text(booGame.msg, tx + 30, ty + th - 34, 0.38)
    djui_hud_set_color(255, 120, 120, a)
    djui_hud_print_text("LIVES " .. booGame.lives .. "  FOUND " .. booGame.found .. "/" .. booGame.total, tx + 30, ty + 12, 0.40)
end
local function draw_platformer(tx, ty, tw, th, a)
    local vx = tx + (tw - PLAT_VIEW_W) / 2 local vy = ty + 48 local cam = plat.cameraX
    draw_rect_a(vx, vy, PLAT_VIEW_W, PLAT_VIEW_H, 105, 175, 255, a)
    draw_rect_a(vx, vy + PLAT_VIEW_H - 90, PLAT_VIEW_W, 90, 35, 155, 45, a)
    for i = 1, #platforms do
        local p = platforms[i] local px = vx + (p.x - cam)
        if px + p.w > vx and px < vx + PLAT_VIEW_W then
            if p.kind == "ground" then
                draw_rect_a(px, vy + p.y, p.w, p.h, 130, 85, 35, a)
                draw_rect_a(px, vy + p.y, p.w, 7, 45, 175, 45, a)
            elseif p.kind == "question" then draw_rect_a(px, vy + p.y, p.w, p.h, 230, 170, 30, a)
            elseif p.kind == "pipe" then draw_rect_a(px, vy + p.y, p.w, p.h, 40, 170, 50, a)
            else draw_rect_a(px, vy + p.y, p.w, p.h, 195, 75, 35, a) end
        end
    end
    draw_mario_sprite(vx + (plat.x - cam), vy + plat.y, plat.w, plat.h, plat.facing, a)
    djui_hud_set_color(255, 230, 80, a)
    djui_hud_print_text("COINS " .. plat.score .. "  LIVES " .. plat.lives, tx + 22, ty + th - 32, 0.44)
end
local function draw_poker(tx, ty, tw, th, a)
    local px, py = tx + 30, ty + 52
    draw_rect_a(px, py, tw - 60, th - 110, 6, 50, 24, a)
    djui_hud_set_color(120, 255, 150, a)
    djui_hud_print_text("LUIGI POKER   CREDITS " .. poker.credits .. "  BET " .. poker.bet, px + 16, py + 12, 0.50)
    local cardW, cardH, gap = 100, 140, 14
    local startX = px + ((tw - 60) - (5 * cardW + 4 * gap)) / 2
    for i = 1, 5 do
        local cx = startX + (i - 1) * (cardW + gap)
        draw_rect_a(cx, py + 88, cardW, cardH, 250, 250, 255, a)
        if poker.hand[i] then
            local card = poker.hand[i] local red = card.suit <= 2
            djui_hud_set_color(red and 210 or 20, red and 25 or 20, red and 25 or 30, a)
            djui_hud_print_text(card.rankName, cx + 12, py + 102, 0.85)
            djui_hud_print_text(card.suitName, cx + 12, py + 145, 0.70)
            djui_hud_print_text(card.suitFull, cx + 10, py + 185, 0.36)
        end
        if poker.phase == "hold" and poker.held[i] then
            draw_rect_a(cx, py + 200, cardW, 28, 25, 150, 65, a)
            djui_hud_set_color(255, 255, 255, a)
            djui_hud_print_text("HOLD", cx + 24, py + 204, 0.46)
        end
        if poker.phase == "hold" and poker.cursor == i then
            draw_rect_a(cx - 4, py + 84, cardW + 8, 5, 255, 230, 50, a)
        end
    end
    djui_hud_set_color(230, 255, 230, a)
    djui_hud_print_text(poker.msg, px + 16, ty + th - 36, 0.42)
end
local function draw_pinball(tx, ty, tw, th, a)
    local ox = tx + (tw - PIN_W) / 2 local oy = ty + 48
    draw_rect_a(ox, oy, PIN_W, PIN_H, 25, 20, 45, a)
    for i = 1, #pin.bumpers do
        local bp = pin.bumpers[i]
        draw_rect_a(ox + bp.x - bp.r, oy + bp.y - bp.r, bp.r * 2, bp.r * 2, 220, 50, 50, a)
    end
    local b = pin.ball
    draw_rect_a(ox + b.x - b.r, oy + b.y - b.r, b.r * 2, b.r * 2, 240, 240, 255, a)
    djui_hud_set_color(255, 220, 100, a)
    djui_hud_print_text("SCORE " .. pin.score .. "  BALLS " .. pin.ballsLeft, tx + 24, ty + th - 32, 0.44)
end
local function draw_dk_game(tx, ty, tw, th, a)
    local vx, vy, s = tx + 50, ty + 52, 1.7
    draw_rect_a(vx, vy, 340 * s, 290, 18, 14, 40, a)
    for i = 1, #dkFloors do
        local f = dkFloors[i]
        draw_rect_a(vx + f.x * s, vy + f.y, f.w * s, 10, 170, 75, 35, a)
    end
    for i = 1, #dk.barrels do
        local b = dk.barrels[i]
        draw_rect_a(vx + b.x * s, vy + b.y, b.w * s, b.h, 150, 85, 30, a)
    end
    draw_mario_sprite(vx + dk.x * s, vy + dk.y, dk.w * s, dk.h, dk.facing, a)
    djui_hud_set_color(255, 220, 100, a)
    djui_hud_print_text("SCORE " .. dk.score .. "  LIVES " .. dk.lives, tx + 24, ty + th - 32, 0.42)
end
local function draw_detective(tx, ty, tw, th, a)
    local cols, rows = detective.cols, detective.rows
    local cellW, cellH = 72, 62
    local startX = tx + (tw - cols * (cellW + 8)) / 2
    local startY = ty + 58
    djui_hud_set_color(255, 220, 100, a)
    djui_hud_print_text(detective.msg, tx + 28, ty + 12, 0.40)
    for i = 1, cols * rows do
        local cell = detective.grid[i]
        if cell then
            local col = ((i - 1) % cols) local row = math.floor((i - 1) / cols)
            local x = startX + col * (cellW + 8) local y = startY + row * (cellH + 8)
            local fc = FACE_COLORS[cell.type]
            if cell.found then draw_rect_a(x, y, cellW, cellH, 35, 35, 35, a)
            else
                draw_rect_a(x, y, cellW, cellH, fc[1], fc[2], fc[3], a)
                draw_rect_a(x + 14, y + 16, 11, 11, 25, 25, 25, a)
                draw_rect_a(x + cellW - 25, y + 16, 11, 11, 25, 25, 25, a)
            end
            if detective.cursor == i then draw_rect_a(x - 3, y - 3, cellW + 6, 3, 255, 240, 70, a) end
        end
    end
end
local function draw_bowser_fight(tx, ty, tw, th, a)
    local bx, by = tx + 40, ty + 54
    draw_rect_a(bx, by, DRM_W * DRM_CELL, DRM_H * DRM_CELL, 12, 8, 16, a)
    for y = 1, DRM_H do for x = 1, DRM_W do
        local cell = drm.grid[y][x]
        if cell.c ~= COL_EMPTY then
            local r, g, b = drm_color_rgb(cell.c)
            draw_rect_a(bx + (x - 1) * DRM_CELL + 1, by + (y - 1) * DRM_CELL + 1, DRM_CELL - 2, DRM_CELL - 2, r, g, b, a)
        end
    end end
    if drm.pill then
        for _, cell in ipairs(drm_pill_cells(drm.pill)) do
            if drm_in_bounds(cell.x, cell.y) then
                local r, g, b = drm_color_rgb(cell.c)
                draw_rect_a(bx + (cell.x - 1) * DRM_CELL + 1, by + (cell.y - 1) * DRM_CELL + 1, DRM_CELL - 2, DRM_CELL - 2, r, g, b, a)
            end
        end
    end
    djui_hud_set_color(255, 200, 120, a)
    djui_hud_print_text("STAGE " .. drm.level .. "  VIRUSES " .. drm.virusesLeft, tx + 40, ty + th - 32, 0.40)
end
local function draw_snake_game(tx, ty, tw, th, a)
    local body = snake_parse_body()
    local gx = tx + (tw - GRID_W * CELL) / 2 local gy = ty + 52
    draw_rect_a(gx, gy, GRID_W * CELL, GRID_H * CELL, 12, 26, 16, a)
    draw_rect_a(gx + (gGlobalSyncTable.snakeFoodX or 0) * CELL + 2, gy + (gGlobalSyncTable.snakeFoodY or 0) * CELL + 2, CELL - 4, CELL - 4, 255, 70, 70, a)
    for i = 1, #body do
        local s = body[i]
        draw_rect_a(gx + s.x * CELL + 1, gy + s.y * CELL + 1, CELL - 2, CELL - 2, i == 1 and 150 or 50, i == 1 and 255 or 190, 90, a)
    end
    djui_hud_set_color(200, 255, 210, a)
    djui_hud_print_text("SCORE " .. tostring(gGlobalSyncTable.snakeScore or 0), tx + 22, ty + th - 32, 0.48)
end

------------------------------------------------------------
-- THEMED TERMINAL SHELL
------------------------------------------------------------
local function draw_theme_effects(tx, ty, tw, th, a, thm)
    if TERM_THEME == 2 then -- CRT scanlines
        for y = 0, th, 3 do
            draw_rect_a(tx, ty + y, tw, 1, 0, 0, 0, to_int(a * 0.25))
        end
        -- vignette-ish side bars
        draw_rect_a(tx, ty, 8, th, 0, 0, 0, to_int(a * 0.35))
        draw_rect_a(tx + tw - 8, ty, 8, th, 0, 0, 0, to_int(a * 0.35))
    elseif TERM_THEME == 3 then -- VHS tracking lines
        local offset = (math.floor(get_global_timer() / 2) % 40)
        draw_rect_a(tx, ty + 40 + offset * 8, tw, 3, 255, 255, 255, to_int(a * 0.08))
        draw_rect_a(tx, ty + 120 + offset * 3, tw, 2, 255, 100, 150, to_int(a * 0.06))
        for y = 0, th, 4 do
            draw_rect_a(tx, ty + y, tw, 1, 0, 0, 0, to_int(a * 0.12))
        end
    elseif TERM_THEME == 5 then -- N64 corner accents
        -- red / gold / blue corners like SM64 UI
        draw_rect_a(tx, ty, 40, 6, 220, 40, 40, a)
        draw_rect_a(tx, ty, 6, 40, 220, 40, 40, a)
        draw_rect_a(tx + tw - 40, ty, 40, 6, 50, 80, 220, a)
        draw_rect_a(tx + tw - 6, ty, 6, 40, 50, 80, 220, a)
        draw_rect_a(tx, ty + th - 6, 40, 6, 255, 200, 50, a)
        draw_rect_a(tx, ty + th - 40, 6, 40, 255, 200, 50, a)
        draw_rect_a(tx + tw - 40, ty + th - 6, 40, 6, 40, 180, 60, a)
        draw_rect_a(tx + tw - 6, ty + th - 40, 6, 40, 40, 180, 60, a)
    end
end

local function draw_terminal()
    if not TERM_OPEN and TERM_ALPHA <= 0 then return end
    if TERM_OPEN then TERM_ALPHA = math.min(245, TERM_ALPHA + 26) else TERM_ALPHA = math.max(0, TERM_ALPHA - 26) end
    local a = to_int(TERM_ALPHA)
    if a <= 0 then return end

    local thm = theme_colors()
    local sw, sh = djui_hud_get_screen_width(), djui_hud_get_screen_height()
    local tw = math.min(960, sw - 20)
    local th = math.min(530, sh - 36)
    local tx = (sw - tw) / 2
    local ty = (sh - th) / 2 - 4

    djui_hud_set_resolution(RESOLUTION_DJUI)
    djui_hud_set_font(FONT_NORMAL)

    -- shadow + body
    draw_rect_a(tx + 10, ty + 10, tw, th, thm.shadow[1], thm.shadow[2], thm.shadow[3], to_int(a * 0.55))
    draw_rect_a(tx, ty, tw, th, thm.bg[1], thm.bg[2], thm.bg[3], a)

    -- borders
    draw_rect_a(tx, ty, tw, 4, thm.border[1], thm.border[2], thm.border[3], a)
    draw_rect_a(tx, ty + th - 4, tw, 4, thm.border[1], thm.border[2], thm.border[3], a)
    draw_rect_a(tx, ty, 4, th, thm.border[1], thm.border[2], thm.border[3], a)
    draw_rect_a(tx + tw - 4, ty, 4, th, thm.border[1], thm.border[2], thm.border[3], a)

    -- header bar
    draw_rect_a(tx + 4, ty + 4, tw - 8, 42, thm.header[1], thm.header[2], thm.header[3], a)
    djui_hud_set_color(thm.accent[1], thm.accent[2], thm.accent[3], a)
    djui_hud_print_text("SM64 TERMINAL", tx + 22, ty + 12, 0.74)

    local rightInfo = "READY"
    if gGlobalSyncTable.lakPlaying then rightInfo = "LAKITU"
    elseif gGlobalSyncTable.bbPlaying then rightInfo = "BASEBALL"
    elseif gGlobalSyncTable.booPlaying then rightInfo = "BOOS"
    elseif gGlobalSyncTable.pinPlaying then rightInfo = "PINBALL"
    elseif gGlobalSyncTable.drmPlaying then rightInfo = "BOWSER"
    elseif gGlobalSyncTable.platPlaying then rightInfo = "2D MARIO"
    elseif gGlobalSyncTable.snakePlaying then rightInfo = "SNAKE"
    elseif gGlobalSyncTable.dkPlaying then rightInfo = "DK"
    elseif gGlobalSyncTable.pokerPlaying then rightInfo = "POKER"
    elseif gGlobalSyncTable.detectivePlaying then rightInfo = "DETECTIVE" end
    djui_hud_set_color(thm.accent[1], thm.accent[2], thm.accent[3], a)
    djui_hud_print_text(rightInfo, tx + tw - 190, ty + 14, 0.50)

    -- theme label
    djui_hud_set_color(thm.dim[1], thm.dim[2], thm.dim[3], a)
    djui_hud_print_text(THEME_NAMES[TERM_THEME], tx + tw - 320, ty + 16, 0.36)

    draw_rect_a(tx + 4, ty + 46, tw - 8, 2, thm.border[1], thm.border[2], thm.border[3], to_int(a * 0.7))

    draw_theme_effects(tx, ty, tw, th, a, thm)

    if gGlobalSyncTable.lakPlaying then draw_lakitu(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.bbPlaying then draw_baseball(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.booPlaying then draw_boo_game(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.pinPlaying then draw_pinball(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.drmPlaying then draw_bowser_fight(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.platPlaying then draw_platformer(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.snakePlaying then draw_snake_game(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.dkPlaying then draw_dk_game(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.pokerPlaying then draw_poker(tx, ty, tw, th, a)
    elseif gGlobalSyncTable.detectivePlaying then draw_detective(tx, ty, tw, th, a)
    else
        -- Centered list area
        local contentTop = ty + 60
        local contentH = th - 130
        local lineScale = 0.54
        local lineH = 22
        local startY = contentTop + 8

        for i = 1, #TERM_LINES do
            local line = TERM_LINES[i]
            local textW = djui_hud_measure_text(line) * lineScale
            local lx = tx + (tw - textW) * 0.5
            djui_hud_set_color(thm.text[1], thm.text[2], thm.text[3], a)
            djui_hud_print_text(line, lx, startY + (i - 1) * lineH, lineScale)
        end

        -- Command entry bar (improved)
        local barH = 52
        local barY = ty + th - barH - 4
        draw_rect_a(tx + 6, barY, tw - 12, barH, thm.panel[1], thm.panel[2], thm.panel[3], a)
        draw_rect_a(tx + 6, barY, tw - 12, 2, thm.border[1], thm.border[2], thm.border[3], to_int(a * 0.8))

        -- prompt
        djui_hud_set_color(thm.accent[1], thm.accent[2], thm.accent[3], a)
        djui_hud_print_text(">", tx + 20, barY + 8, 0.58)
        djui_hud_print_text("/term <command>", tx + 42, barY + 8, 0.52)

        -- hint row centered
        local hint = "help   theme   lakitu   baseball   boo   2d   pinball   spawn   power"
        local hintW = djui_hud_measure_text(hint) * 0.32
        djui_hud_set_color(thm.dim[1], thm.dim[2], thm.dim[3], a)
        djui_hud_print_text(hint, tx + (tw - hintW) * 0.5, barY + 30, 0.32)
    end
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_BEFORE_SET_MARIO_ACTION, before_set_mario_action)
hook_event(HOOK_UPDATE, update)
hook_event(HOOK_ON_HUD_RENDER, draw_terminal)
hook_chat_command("term", "[command]", term_command)

hook_mod_menu_text("SM64 Terminal")
hook_mod_menu_checkbox("Open Terminal", false, function(_, v) TERM_OPEN = v end)
hook_mod_menu_text("Terminal Theme")
hook_mod_menu_button("Theme: Green", function() TERM_THEME = 1 term_print("Theme: Green") end)
hook_mod_menu_button("Theme: CRT", function() TERM_THEME = 2 term_print("Theme: CRT") end)
hook_mod_menu_button("Theme: VHS", function() TERM_THEME = 3 term_print("Theme: VHS") end)
hook_mod_menu_button("Theme: Purple", function() TERM_THEME = 4 term_print("Theme: Purple") end)
hook_mod_menu_button("Theme: N64", function() TERM_THEME = 5 term_print("Theme: N64") end)
hook_mod_menu_button("Lakitu Launch", function() lak_start() end)
hook_mod_menu_button("Baseball", function() bb_start() end)
hook_mod_menu_button("Boo Hide & Seek", function() boo_start() end)
hook_mod_menu_button("2D Mario", function() plat_start() end)
hook_mod_menu_button("Stop All", function() stop_all_minigames() end)

if gGlobalSyncTable.snakePlaying == nil then
    gGlobalSyncTable.snakePlaying = false
    gGlobalSyncTable.platPlaying = false
    gGlobalSyncTable.drmPlaying = false
    gGlobalSyncTable.dkPlaying = false
    gGlobalSyncTable.pokerPlaying = false
    gGlobalSyncTable.detectivePlaying = false
    gGlobalSyncTable.pinPlaying = false
    gGlobalSyncTable.lakPlaying = false
    gGlobalSyncTable.bbPlaying = false
    gGlobalSyncTable.booPlaying = false
    snake_init_state()
end

term_print("SM64 Terminal loaded.")
term_print("Type help  |  theme 1-5")
print("[SM64 Terminal] Loaded.")